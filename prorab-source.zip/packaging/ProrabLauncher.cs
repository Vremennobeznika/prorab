using System;
using System.Diagnostics;
using System.Drawing;
using System.IO;
using System.Text;
using System.Threading;
using System.Windows.Forms;
using System.Web.Script.Serialization;

// Тихий запуск без терминала. Папка программы доступна только для чтения.
// Настройки и рабочие документы — в %LOCALAPPDATA%\Prorab.
internal static class Program {
    private static Process server;
    private static NotifyIcon tray;
    private static string workspace;
    private static string readyFile;
    private static string currentUrl;

    [STAThread]
    private static void Main() {
        Application.EnableVisualStyles();
        Application.SetCompatibleTextRenderingDefault(false);
        string root = AppDomain.CurrentDomain.BaseDirectory;
        string executable = Path.Combine(root, "runtime", "node.exe");
        string script = Path.Combine(root, "app", "src", "main.js");
        if (!File.Exists(executable) || !File.Exists(script)) {
            MessageBox.Show("Файлы программы повреждены. Переустановите Прораб.", "Прораб", MessageBoxButtons.OK, MessageBoxIcon.Error);
            return;
        }
        string userDir = Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.LocalApplicationData), "Prorab");
        workspace = Path.Combine(userDir, "workspace");
        Directory.CreateDirectory(userDir);
        Directory.CreateDirectory(workspace);
        readyFile = Path.Combine(userDir, "launch-" + Guid.NewGuid().ToString("N") + ".json");
        var context = new ApplicationContext();
        var menu = new ContextMenuStrip();
        menu.Items.Add("Открыть Прораб", null, (s, e) => OpenUrl());
        menu.Items.Add("Мои файлы", null, (s, e) => Process.Start("explorer.exe", "\"" + workspace + "\""));
        menu.Items.Add("Выход", null, (s, e) => { Stop(); context.ExitThread(); });
        tray = new NotifyIcon { Icon = SystemIcons.Application, Visible = true, Text = "Прораб", ContextMenuStrip = menu };
        tray.DoubleClick += (s, e) => OpenUrl();
        context.ThreadExit += (s, e) => Stop();
        try {
            var start = new ProcessStartInfo(executable) {
                Arguments = "\"" + script + "\" --no-open --port 0 --ready-file \"" + readyFile + "\"",
                WorkingDirectory = Path.Combine(root, "app"),
                UseShellExecute = false,
                CreateNoWindow = true,
                WindowStyle = ProcessWindowStyle.Hidden
            };
            start.EnvironmentVariables["PRORAB_USER_DIR"] = userDir;
            server = Process.Start(start);
            // UI dispatcher must be declared before the worker closure uses it.
            var invisible = new Form { ShowInTaskbar = false, WindowState = FormWindowState.Minimized };
            invisible.Load += (s, e) => invisible.Hide();
            context.MainForm = invisible;
            IntPtr uiHandle = invisible.Handle;
            var thread = new Thread(() => {
                for (int i = 0; i < 300; i++) {
                    if (server.HasExited) break;
                    try {
                        if (File.Exists(readyFile)) {
                            var json = new JavaScriptSerializer().DeserializeObject(File.ReadAllText(readyFile, Encoding.UTF8)) as System.Collections.Generic.Dictionary<string, object>;
                            if (json != null && json.ContainsKey("url")) {
                                currentUrl = Convert.ToString(json["url"]);
                                invisible.BeginInvoke((MethodInvoker)(() => OpenUrl()));
                                return;
                            }
                        }
                    } catch { /* файл записи ещё не закончен */ }
                    Thread.Sleep(100);
                }
                invisible.BeginInvoke((MethodInvoker)(() => {
                    MessageBox.Show("Не удалось запустить Прораб. Проверьте, не блокирует ли программу антивирус, или переустановите приложение.", "Прораб", MessageBoxButtons.OK, MessageBoxIcon.Error);
                    Stop(); context.ExitThread();
                }));
            });
            thread.IsBackground = true;
            thread.Start();
            Application.Run(context);
        } catch (Exception ex) {
            MessageBox.Show("Ошибка запуска: " + ex.Message, "Прораб", MessageBoxButtons.OK, MessageBoxIcon.Error);
            Stop();
        }
    }
    private static void OpenUrl() {
        if (string.IsNullOrEmpty(currentUrl)) return;
        try { Process.Start(new ProcessStartInfo(currentUrl) { UseShellExecute = true }); }
        catch { MessageBox.Show("Не удалось открыть браузер. Проверьте браузер по умолчанию.", "Прораб"); }
    }
    private static void Stop() {
        if (tray != null) { tray.Visible = false; tray.Dispose(); tray = null; }
        try { if (server != null && !server.HasExited) server.Kill(); } catch { }
        try { if (readyFile != null && File.Exists(readyFile)) File.Delete(readyFile); } catch { }
    }
}
