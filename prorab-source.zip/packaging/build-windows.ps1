$ErrorActionPreference = 'Stop'
Set-StrictMode -Version Latest
$root = (Resolve-Path (Join-Path $PSScriptRoot '..')).Path
$build = Join-Path $root 'build'
$dist = Join-Path $root 'dist'
New-Item -ItemType Directory -Path $build, $dist -Force | Out-Null
$runtime = Join-Path $build 'runtime'
$app = Join-Path $build 'app'
New-Item -ItemType Directory -Path $runtime, $app -Force | Out-Null
$node = (Get-Command node.exe -ErrorAction Stop).Source
Copy-Item $node (Join-Path $runtime 'node.exe') -Force
$nodeDir = Split-Path $node -Parent
$nodeLicense = @(
  (Join-Path $nodeDir 'LICENSE'),
  (Join-Path (Split-Path $nodeDir -Parent) 'LICENSE')
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if ($nodeLicense) { Copy-Item $nodeLicense (Join-Path $runtime 'NODE-LICENSE.txt') -Force }
else { throw 'Не найдена лицензия Node.js для включения в дистрибутив.' }
foreach ($name in @('src','web','agents','config','certs')) {
  Copy-Item (Join-Path $root $name) (Join-Path $app $name) -Recurse -Force
}
# Windows 10/11 ships .NET Framework. PowerShell 5.1 compiles a native-looking GUI launcher,
# which starts the bundled Node runtime invisibly. No npm install or internet at runtime.
Add-Type -Path (Join-Path $PSScriptRoot 'ProrabLauncher.cs') `
  -OutputAssembly (Join-Path $build 'Прораб.exe') -OutputType WindowsApplication `
  -ReferencedAssemblies @('System.dll','System.Core.dll','System.Drawing.dll','System.Windows.Forms.dll','System.Web.Extensions.dll')
$inno = @(
  "${env:ProgramFiles(x86)}\Inno Setup 6\ISCC.exe",
  "$env:ProgramFiles\Inno Setup 6\ISCC.exe"
) | Where-Object { Test-Path $_ } | Select-Object -First 1
if (-not $inno) { throw 'Требуется Inno Setup 6 для формирования установщика.' }
& $inno (Join-Path $PSScriptRoot 'Prorab.iss')
if ($LASTEXITCODE -ne 0) { throw "Сборка инсталлятора завершилась с кодом $LASTEXITCODE" }
Get-FileHash (Join-Path $dist 'Prorab-Setup-0.3.2.exe') -Algorithm SHA256
