// «Склейка»: собирает все части в одно приложение и даёт серверу простые команды —
// запустить агента, остановить всех, показать состояние. Сам сервер про устройство частей не знает.
import fs from 'node:fs';
import path from 'node:path';
import { createApprovals } from './agent/approvals.js';
import { createMemory, recallContext } from './agent/memory.js';
import { createRuns } from './agent/runs.js';
import { runAgent } from './agent/runner.js';
import { createPool } from './pool/pool.js';
import { createQuota } from './pool/quota.js';
import { buildProviders } from './pool/registry.js';
import { UserError } from './util/errors.js';
import { ROOT } from './util/paths.js';
import { writeJson } from './util/files.js';

const MAX_TASK_CHARS = 4000;
const DEFAULT_MAX_CONCURRENT_RUNS = 3; // на слабом компьютере много одновременных агентов только мешают друг другу

export function createApp({ settings, providerConfigs, agents, dataDir, env = process.env, workspace: workspaceOverride, providerConfigFile, envFile }) {
  // Рабочая папка агентов. Относительный путь считается от папки проекта.
  const workspace = workspaceOverride ? path.resolve(workspaceOverride) : path.resolve(ROOT, settings.workspace ?? './workspace');
  fs.mkdirSync(workspace, { recursive: true });

  const quota = createQuota({ file: path.join(dataDir, 'quota.json') });
  let pool = createPool({ providers: buildProviders(providerConfigs, env), quota });
  const runs = createRuns({ dir: path.join(dataDir, 'runs') });
  const memory = createMemory({ file: path.join(dataDir, 'memory.json') });
  const approvals = createApprovals({ runs });
  const maxRuns = settings.maxConcurrentRuns ?? DEFAULT_MAX_CONCURRENT_RUNS;
  // Имена переменных с ключами из providers.json: команды агента их не увидят (см. cleanEnv в tools.js).
  const secretEnvNames = providerConfigs.flatMap((p) => [p.apiKeyEnv, p.authKeyEnv]).filter(Boolean);

  /** Запускает агента в фоне и сразу возвращает id запуска. */
  // Менять поставщика можно в браузере. Конфигурация сохраняется в профиле пользователя;
  // уже работающие задачи завершаются со своим существующим пулом моделей.
  function configureProvider({ providerId, enabled, apiKey }) {
    if (!providerConfigFile || !envFile) throw new UserError('Настройка из браузера недоступна в тестовом режиме.', 403);
    if (runs.countRunning() !== 0) throw new UserError('Дождитесь окончания задач перед сменой модели.', 409);
    const config = providerConfigs.find((p) => p.id === providerId);
    if (!config) throw new UserError('Неизвестная модель.', 400);
    if (typeof enabled !== 'boolean') throw new UserError('Укажите, включить ли модель.', 400);
    if (apiKey !== undefined && (typeof apiKey !== 'string' || apiKey.length > 4096 || /[\r\n]/.test(apiKey))) {
      throw new UserError('Некорректный ключ доступа.', 400);
    }
    const nextEnv = { ...env };
    const envName = config.authKeyEnv || config.apiKeyEnv;
    if (apiKey && !envName) throw new UserError('Для этой модели ключ не требуется.', 400);
    if (apiKey) nextEnv[envName] = apiKey.trim();
    const nextConfigs = providerConfigs.map((p) => ({ ...p, enabled: p.id === providerId ? enabled : p.enabled }));
    const nextPool = createPool({ providers: buildProviders(nextConfigs, nextEnv), quota });
    if (enabled && envName && !nextPool.status().find((p) => p.id === providerId)?.ready.ok) {
      throw new UserError('Для выбранной модели сначала укажите ключ доступа.', 400);
    }
    // Не записываем секрет в JSON настроек или ответы API.
    if (apiKey) {
      const existing = fs.existsSync(envFile) ? fs.readFileSync(envFile, 'utf8') : '';
      const without = existing.split(/\r?\n/).filter((line) => !line.startsWith(`${envName}=`)).join('\n').trim();
      fs.mkdirSync(path.dirname(envFile), { recursive: true });
      fs.writeFileSync(envFile, `${without ? `${without}\n` : ''}${envName}=${apiKey.trim()}\n`, { mode: 0o600 });
    }
    writeJson(providerConfigFile, { providers: nextConfigs });
    for (let i = 0; i < nextConfigs.length; i += 1) providerConfigs[i] = nextConfigs[i];
    if (apiKey) env[envName] = apiKey.trim();
    pool = nextPool;
    return { ok: true };
  }

  function startRun(agentId, task, { useMemory = false, criteria = '' } = {}) {
    if (typeof criteria !== 'string' || criteria.length > 2000) throw new UserError('Критерии готовности: максимум 2000 символов.');
    if (typeof useMemory !== 'boolean') throw new UserError('Некорректная настройка памяти.');
    const agent = agents.find((a) => a.id === agentId);
    if (!agent) throw new UserError('Такого агента нет. Выберите агента из списка.');
    const cleanTask = String(task ?? '').trim();
    if (!cleanTask) throw new UserError('Опишите задачу: что агент должен сделать.');
    if (cleanTask.length > MAX_TASK_CHARS) throw new UserError(`Задача слишком длинная (максимум ${MAX_TASK_CHARS} символов).`);

    const running = runs.countRunning();
    if (!pool.status().some((p) => p.enabled && p.ready.ok)) {
      throw new UserError('Сначала подключите ИИ во вкладке «Модели».', 409);
    }
    if (running >= maxRuns) {
      throw new UserError(`Уже идёт ${running} из ${maxRuns} возможных запусков. Дождитесь завершения или остановите лишние.`, 429);
    }

    const { id, signal } = runs.create({ agentId: agent.id, agentName: agent.name, task: cleanTask, localOnly: Boolean(agent.localOnly), useMemory, criteria: criteria.trim() });
    const backupDir = path.join(dataDir, 'backups', id);

    let recalled = [];
    if (useMemory) {
      try {
        recalled = recallContext({ memory, runs, task: cleanTask, agent });
        runs.emit(id, 'memory_recalled', { sources: recalled.map(({ kind, id }) => ({ kind, id })) });
      } catch (err) {
        runs.emit(id, 'memory_unavailable', { message: err.message });
      }
    }

    // Не ждём окончания: агент работает в фоне, а мы отвечаем странице сразу.
    runAgent({ agent, task: cleanTask, runId: id, pool, runs, approvals, workspace, backupDir, signal, secretEnvNames, recalled, criteria: criteria.trim() })
      .then((result) => {
        runs.finish(id, result.status === 'done' ? 'done' : 'failed', { answer: result.answer });
      })
      .catch((err) => {
        if (signal.aborted) {
          runs.finish(id, 'stopped');
        } else {
          runs.emit(id, 'error', { message: err.message });
          runs.finish(id, 'failed', { note: err.message });
        }
      });

    return id;
  }

  function saveMemory(body) {
    if (!body || typeof body !== 'object' || Array.isArray(body)) throw new UserError('Некорректная заметка.');
    const previous = body.id === undefined ? null : memory.list().find((n) => n.id === body.id);
    const sourceId = previous?.sourceRunId || body.sourceRunId;
    const source = sourceId == null ? null : runs.get(sourceId);
    if (sourceId != null && (!source || source.status !== 'done')) throw new UserError('Завершённый запуск не найден.', 404);
    if ((previous?.sourceLocalOnly || (source && source.localOnly !== false)) && body.localOnly === false) throw new UserError('Заметка из локального запуска должна оставаться локальной.');
    return memory.put({ ...body, sourceRunId: sourceId || null, sourceLocalOnly: Boolean(previous?.sourceLocalOnly || (source && source.localOnly !== false)) });
  }

  /** Всё, что нужно странице для отрисовки. */
  function state() {
    return {
      workspace,
      canConfigure: Boolean(providerConfigFile && envFile),
      agents: agents.map(({ instructions, ...visible }) => visible),
      providers: pool.status(),
      runs: runs.list(),
      approvals: approvals.list(),
    };
  }

  return { workspace, get pool() { return pool; }, runs, approvals, memory, saveMemory, configureProvider, startRun, state, stopAll: () => runs.stopAll() };
}
